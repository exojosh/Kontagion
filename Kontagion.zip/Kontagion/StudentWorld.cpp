#include "StudentWorld.h"
#include "GameConstants.h"
#include "Actor.h"

using namespace std;

double distance(double x1, double y1, double x2, double y2)
{
    return sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
}

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h and Actor.cpp

StudentWorld::StudentWorld(string assetPath) : GameWorld(assetPath)
{

}
StudentWorld::~StudentWorld()
{
    this->cleanUp();
}

void StudentWorld::addActor(Actor* a)
{
    masterList.push_back(a);
}

bool StudentWorld::initHelper(double x, double y) //Cycles thru all members of masterlist and checks if any overlap.
{
    std::list<Actor*>::const_iterator it = masterList.begin();
    for (it = masterList.begin(); it != masterList.end(); it++)
    {
        if (distance(x, y, (*it)->getX(), (*it)->getY()) <= SPRITE_WIDTH)
            return true;
    }
    return false;
}

int StudentWorld::init() //Iniitalizes all actors per level.
{
    m_socrates = new Socrates(this);
    m_socrates->setHP(100);
    m_socrates->setAlive(true);


    Actor* dummy;
    int a, r;
    double x, y;
    for (int i = 0; i < getLevel(); i++)
    {
        {
            a = randInt(0, 359);
            r = sqrt(randInt(0, 120 * 120));
            x = VIEW_WIDTH / 2 - r * cos((a * 2. * 3.141515926) / 360);
            y = VIEW_HEIGHT / 2 - r * sin((a * 2. * 3.1415926) / 360);
            dummy = new Pit(this, x, y);
            if (initHelper(x, y) == false)
                addActor(dummy);
            else { i--; delete dummy; }
        }
    } //For loop above initializes pit(s)

    for (int i = 0; i < min(5 * getLevel(), 25); i++)
    {
        {
            a = randInt(0, 359);
            r = sqrt(randInt(0, 120 * 120));
            x = VIEW_WIDTH / 2 - r * cos((a * 2. * 3.141515926) / 360);
            y = VIEW_HEIGHT / 2 - r * sin((a * 2. * 3.1415926) / 360);
            dummy = new Food(this, x, y);
            if (initHelper(x, y) == false)
                addActor(dummy);
            else { i--; delete dummy; }
        }
    }//For loop above initializes foods that don't overlap with pits
    std::list<Actor*> dirtList;
    for (int i = 0; i < max(180 - 20 * getLevel(), 20); i++)
    {
        a = randInt(0, 359);
        r = sqrt(randInt(0, 120*120));
        x = VIEW_WIDTH / 2 - r * cos((a * 2. * 3.141515926) / 360);
        y = VIEW_HEIGHT / 2 - r * sin((a * 2. * 3.1415926) / 360);
        dummy = new DirtPile(this, x, y);
        if (initHelper(x, y) == false)
            dirtList.push_back(dummy);
        else { i--; delete dummy; }
    }
    while (!dirtList.empty())
    {
        addActor(dirtList.front());
        dirtList.pop_front();
    } //while and for loop above initializes dirt piles such that they may overlap with each other but not pits or food.
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    ostringstream oss;
    oss.setf(ios::fixed);
    oss << "Score: " << setw(6);
    oss.fill('0');
    oss << getScore();
    oss.fill(' ');
    oss << "  Level: " << getLevel() << "  Lives: " << getLives() << "  Health: " << m_socrates->getHP() << "  Sprays: " << setw(2) << m_socrates->getSpray() << "  Flames: " << m_socrates->getFlame();
    string s = oss.str();
    setGameStatText(s);  //All code above is merely to display the scoreboard and format it properly.

    m_socrates->doSomething();
    if (!m_socrates->isAlive())
    {
        playSound(SOUND_PLAYER_DIE);
        decLives();
        return GWSTATUS_PLAYER_DIED;
    }

    std::list<Actor*>::iterator it = masterList.begin();
    bool finish = false;
    for (; it != masterList.end(); it++)
    {
        if ((*it)->preventsLevelCompleteing())
            finish = true;
    } //Checks if any actors prevent level from being completed.
    if (!finish)
    {
        playSound(SOUND_FINISHED_LEVEL);
        return GWSTATUS_FINISHED_LEVEL;
    }
    it = masterList.begin();
    for (; it != masterList.end(); it++)
    {
        (*it)->doSomething();
    }
    it = masterList.begin();
    while( it != masterList.end())
    {
        if (!(*it)->isAlive())
        {
            delete (*it); 
            it = masterList.erase(it);
        }
        else it++;
    }
    double x, y;
    int rand, ChanceGoodie = max(510 - 10 * getLevel(), 250), ChanceFungus = max(510 - 10 * getLevel(), 200);
    if (randInt(0, ChanceFungus - 1) == 0)
    {
        getPositionOnCircumference(randInt(0, 359), x, y);
        addActor(new Fungus(this, x, y));
    }
    if (randInt(0, ChanceGoodie - 1) == 0)
    {
        rand = randInt(0, 9);
        getPositionOnCircumference(randInt(0, 359), x, y);
        if(rand <= 5)
            addActor(new health_Goodie(this, x, y));
        else if(rand <= 8)
            addActor(new flame_Goodie(this, x, y));
        else
            addActor(new life_Goodie(this, x, y));
    } //Chance to spawn fungi and goodies on each tick.
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    delete m_socrates;
    while(masterList.begin() != masterList.end())
    {
        delete *masterList.begin();
        masterList.pop_front();

    }
} //Deletes all dynamically allocated actors.

bool StudentWorld::damageActor(Actor* a, int damage)
{
    std::list<Actor*>::iterator it = masterList.begin();
    double x = a->getX(), y = a->getY(), s, t;
    for (; it != masterList.end() && (*it) != a; it++)
    {
        s = (*it)->getX();
        t = (*it)->getY();
        if (distance(x, y, s, t) <= SPRITE_WIDTH)
        {
            if((*it)->isAlive() && 
                
                (*it)->takeDamage(damage))
            return true;
        }
    }
    return false;
} //Goes thru all actors and sees if it can damage one that overlaps with "a"

bool StudentWorld::isBacteriumMovementBlockedAt(double x, double y) const
{
    std::list<Actor*>::const_iterator it = masterList.begin();
    double s, t;
    for (; it != masterList.end(); it++)
    {
        if ((*it)->blocksBacteriumMovement())
        {
            s = (*it)->getX();
            t = (*it)->getY();
            if (distance(x, y, s, t) <= SPRITE_WIDTH / 2.)
                return true;
        }
    }
    if (distance(x, y, VIEW_WIDTH / 2., VIEW_HEIGHT / 2.) > VIEW_RADIUS)
        return true;
    else return false;
} //Iterates over all actors to see if any that overlap with the given x and y coordinate prevent bacteria from moving onto that spot.

bool StudentWorld::getAngleToNearbySocrates(Actor* a, int dist, int& angle) const
{
    double x = a->getX(), y = a->getY(), c, d;
    if (distance(x, y, m_socrates->getX(), m_socrates->getY()) <= dist)
    {
        c = m_socrates->getX() - x, d = m_socrates->getY() - y;
        if (atan2(d, c) < 0)
            angle = 360 + (atan2(d, c) * 180. / 3.1415926);
        else angle = atan2(d, c) * 180. / 3.1415926; //Gets proper angle and sets angle to it.
        return true;
    }
    return false;
}//if socrates is within dist of a, set angle to angle to socrates from a.

bool StudentWorld::getAngleToNearestNearbyEdible(Actor* a, int dist, int& angle) const
{
    std::list<Actor*>::const_iterator it = masterList.begin();
    double x = a->getX(), y = a->getY(), s, t, s_final, t_final;
    int final = -1;
    for (; it != masterList.end(); it++)
    {
        if ((*it)->isEdible())
        {
            s = (*it)->getX();
            t = (*it)->getY();
            int temp = distance(x, y, s, t);
            if (temp <= dist)
            {
                if (temp < final || final == -1)
                {
                    final = temp;
                    s_final = s;
                    t_final = t;
                }
            }
        }

    } //Check not only if each actor is edible, but also if it is closer than last stored edible distance.
    if (final != -1)
    {
        s = s_final - x, t = t_final - y;
        if (atan2(t, s) < 0)
            angle = 360 + (atan2(t, s) * 180. / 3.1415926);
        else angle = atan2(t, s) * 180. / 3.1415926;; 
        return true;
    } //if we found an edible actor, set angle to the closest one and return true, otherwise return false.
    else return false;
}

void StudentWorld::getPositionOnCircumference(int a, double& x, double& y)
{
    x = VIEW_WIDTH / 2 - VIEW_WIDTH / 2 * cos(((2 * 3.141592653) / 360) * a);
    y = VIEW_WIDTH / 2 - VIEW_WIDTH / 2 * sin(((2 * 3.141592653) / 360) * a);
} //Gives position on circumference of the circle for socrates, fungi, and goodies.

Socrates* StudentWorld::socratesOverlap(Actor* me)
{
    if (me == nullptr)
        return nullptr;
    double x = me->getX(), y = me->getY();
    if (distance(x, y, m_socrates->getX(), m_socrates->getY()) <= (SPRITE_WIDTH/2.))
        return m_socrates;
    else return nullptr;
} //Determines if me overlaps with socrates and returns socrates' pointer if so and returns nullptr if not.

Actor* StudentWorld::edibleOverlap(Actor* me)
{
    if (me == nullptr)
        return nullptr;
    double s, t, x = me->getX(), y = me->getY();
    std::list<Actor*>::const_iterator it = masterList.begin();
    for (; it != masterList.end(); it++)
    {
        if ((*it)->isEdible())
        {
            s = (*it)->getX();
            t = (*it)->getY();
            if (distance(x, y, s, t) <= SPRITE_WIDTH)
                return (*it);
        }
    } // checks if me overlaps with any edible actors in the list and returns a pointer to that food if so and nullptr if not.
    return nullptr;
}
