#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include <list>
#include <string>
#include <sstream>
#include <iomanip>
#include <cmath>

class Actor;
class Socrates;
class StudentWorld : public GameWorld
{
public:
    StudentWorld(std::string assetPath);
    ~StudentWorld();

    void addActor(Actor* a);

    bool initHelper(double x, double y);

    virtual int init();
    virtual int move();
    virtual void cleanUp();

    bool damageActor(Actor* a, int damage);
    bool isBacteriumMovementBlockedAt(double x, double y) const;

    bool getAngleToNearbySocrates(Actor* a, int dist, int& angle) const;
    bool getAngleToNearestNearbyEdible(Actor* a, int dist, int& angle) const;
    void getPositionOnCircumference(int a, double& x, double& y);

    Socrates* socratesOverlap(Actor* me);   
    Actor* edibleOverlap(Actor* me);
private:
    std::list<Actor*> masterList;
    Socrates* m_socrates;
};

#endif // STUDENTWORLD_H_
