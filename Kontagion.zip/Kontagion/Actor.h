#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include <list>
#include <cmath>



class StudentWorld;

class Actor : public GraphObject
{
public:
	Actor(StudentWorld* s, int imageID, double startX, double startY, Direction dir, int depth);
	void setAlive(bool life);

	virtual bool blocksBacteriumMovement() const { return false; }
	virtual bool isEdible() const { return false; }
	virtual bool preventsLevelCompleteing() const { return false; }
	bool isAlive() const;

	virtual bool takeDamage(int damage) { return false; } //By default objects do not take damage and thus return false. It is not an error that I do not use damage in such cases.

	StudentWorld* getWorld() const;

	void virtual doSomething() =0;

private:
	bool m_alive = true;
	StudentWorld* m_world = nullptr;
};

class Agent : public Actor
{
public:
	Agent(StudentWorld* s, int imageID, double x, double y, int dir);

	void setHP(int new_hp);
	int getHP() const;

	virtual int soundWhenHurt() const = 0;
	virtual int soundWhenDies() const = 0;

private:
	int m_hp = 0;
};

class Socrates : public Agent
{
public:
	Socrates(StudentWorld* s);

	void virtual doSomething();

	virtual bool takeDamage(int damage);

	void setSpray(int spray);
	int getSpray() const;
	void incFlame();
	int getFlame() const;

	inline virtual int soundWhenHurt() const { return SOUND_PLAYER_HURT; }
	inline virtual int soundWhenDies() const { return SOUND_PLAYER_DIE; }
private:
	int m_spray = 20;
	int m_flame = 5;
};

class DirtPile : public Actor
{
public:
	DirtPile(StudentWorld* s, double x, double y);

	virtual bool takeDamage(int damage);
	void virtual doSomething() {};
	virtual bool blocksBacteriumMovement() const { return true; }
};

class Food : public Actor
{
public:
	Food(StudentWorld* s, double x, double y);

	void virtual doSomething() {};
	virtual bool isEdible() const { return true; }
};

class Pit : public Actor
{
public:
	Pit(StudentWorld* s, double x, double y);
	virtual bool preventsLevelCompleteing() const { return true; }
	void virtual doSomething();
public:
	int inventory[3] = { 5, 3, 2 };
};

class Projectile : public Actor 
{
public:
	Projectile(StudentWorld* s, int image, double x, double y, Direction dir, int lifetime, int damage);

	void decLifetime(int lifet);
	int getLifetime() const;

	void setDamage(int d);
	int getDamage() const;

	void virtual doSomething();
private:
	int m_lifetime;
	int m_damage;  //We will use this int value for damage for projectiles and points given for goodies.
};

class Flame : public Projectile
{
public:
	Flame(StudentWorld* s, double x, double y, Direction dir);
};

class Spray : public Projectile
{
public:
	Spray(StudentWorld* s, double x, double y, Direction dir);
};

class Goodie : public Actor 
{
public:
	Goodie(StudentWorld* s, int image, double x, double y);
	void virtual pickUp(Socrates* s) = 0;
	void virtual doSomething();

	void setDecay();
	void setPoints(int newpoints);

	virtual bool takeDamage(int damage);
private:
	int m_decay;
	int m_points = 0;
};

class health_Goodie : public Goodie
{
public:
	health_Goodie(StudentWorld* s, double x, double y);
	void virtual pickUp(Socrates* s);
};

class life_Goodie : public Goodie
{
public:
	life_Goodie(StudentWorld* s, double x, double y);
	void virtual pickUp(Socrates* s);
};

class flame_Goodie : public Goodie
{
public:
	flame_Goodie(StudentWorld* s, double x,  double y);
	void virtual pickUp(Socrates* s);
};

class Fungus : public Goodie
{
public:
	Fungus(StudentWorld* s, double x, double y);
	void virtual pickUp(Socrates* s);
};

class Bacterium : public Agent
{
public:
	Bacterium(StudentWorld* s, int imageID, double x, double y);
	void doSomething();
	virtual bool preventsLevelCompleteing() const { return true; }
	virtual bool takeDamage(int damage);

	void bacteriumCheck();
	bool checkForDirtandMaybeMove();
	virtual void reproduce(double newx, double newy) = 0;

	void setDamage(int damage);
	void setSpeed(int speed);

	virtual bool persueSocrates() = 0;
private:
	int movementPlanDistance = 0;
	int foodEaten = 0;
	int m_damage = 0;
	int m_speed = 0;
};

class Salmonella : public Bacterium
{
public:
	Salmonella(StudentWorld* s, double x, double y);
	inline virtual int soundWhenHurt() const { return SOUND_SALMONELLA_HURT; }
	inline virtual int soundWhenDies() const { return SOUND_SALMONELLA_DIE; }

	void setMovementPlan(int newplan);
	void persueFood();
private:
	int m_movement_plan = 0;
};

class Regular_Salmonella : public Salmonella
{
public:
	Regular_Salmonella(StudentWorld* s, double x, double y);
	void doSomething();
	virtual void reproduce(double newx, double newy);

	virtual bool persueSocrates() { return false; };
};

class Aggressive_Salmonella : public Salmonella
{
public:
	Aggressive_Salmonella(StudentWorld* s, double x, double y);
	void doSomething();
	virtual void reproduce(double newx, double newy);

	virtual bool persueSocrates();
};

class EColi : public Bacterium
{
public:
	EColi(StudentWorld* s, double x, double y);

	virtual bool persueSocrates();
	virtual void reproduce(double newx, double newy);

	void doSomething();
	inline virtual int soundWhenHurt() const { return SOUND_ECOLI_HURT; }
	inline virtual int soundWhenDies() const { return SOUND_ECOLI_DIE; }
};

#endif // ACTOR_H_
