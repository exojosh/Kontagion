#include "Actor.h"
#include "StudentWorld.h"

Actor::Actor(StudentWorld* s, int imageID, double startX, double startY, Direction dir, int depth): GraphObject(imageID, startX, startY, dir, depth, 1.0)
{
	m_world = s;
}
void Actor::setAlive(bool life)
{
	m_alive = life;
}

bool Actor::isAlive() const
{
	return m_alive;
}

Agent::Agent(StudentWorld* s, int imageID, double x, double y, int dir) : Actor(s, imageID, x, y, dir, 0)
{

}

void Agent::setHP(int new_hp)
{
	m_hp = new_hp;
}
int Agent::getHP() const
{
	return m_hp;
}

StudentWorld* Actor::getWorld() const
{
	return m_world;
}

Socrates::Socrates(StudentWorld* s) : Agent(s, IID_PLAYER, 0, 128, 0)
{

}

void Socrates::doSomething()
{
	if (getHP() <= 0)
		setAlive(false);
	if (!this->isAlive())
		return;
	int ch;
	double x, y;
	if (getWorld()->getKey(ch))
	{
		switch (ch)
		{
		case KEY_PRESS_LEFT: 	setDirection(getDirection() - 5);
			this->getWorld()->getPositionOnCircumference(getDirection(), x, y);
			moveTo(x, y);
			break;
		case KEY_PRESS_RIGHT: 	setDirection(getDirection() + 5);
			this->getWorld()->getPositionOnCircumference(getDirection(), x, y);
			moveTo(x, y);
			break;
		case KEY_PRESS_SPACE:
			if (getSpray() <= 0)
				break;
			getWorld()->addActor(new Spray(getWorld(), SPRITE_WIDTH * cos(getDirection() * 3.14159 * 2. / 360.) + this->getX(), SPRITE_WIDTH * sin(getDirection() * 3.14159 * 2. / 360.) + this->getY(), getDirection()));
			m_spray--;
			getWorld()->playSound(SOUND_PLAYER_SPRAY);
			break;
		case KEY_PRESS_ENTER:
			if (getFlame() <= 0)
				break;
			for (int i = 0; i < 16; i++)
			{
				getWorld()->addActor(new Flame(getWorld(), SPRITE_WIDTH * cos(((22. * i) + getDirection()) * 3.14159 * 2. / 360.) + this->getX(), SPRITE_WIDTH * sin(((22. * i) + getDirection()) * 3.14159 * 2. / 360.) + this->getY(), getDirection() + i * 22));
			}
			m_flame--;
			getWorld()->playSound(SOUND_PLAYER_FIRE);
			break;
		}
	}
	else if (m_spray < 20)
		m_spray++;
} //Socrates moves counterclockwise if you press left, clocwise if you press right, sprays if you press spacebar, explodes/shoots flames if you press enter. Also socrates will regenerate sprays if not doing anything else.

bool Socrates::takeDamage(int damage)
{
	getWorld()->playSound(SOUND_PLAYER_HURT);
	setHP(getHP() - damage);
	return true;
} //Socrates takes damage and plays player hurt sound effect when he does.

void Socrates::setSpray(int spray)
{
	m_spray = spray;
} //sets the amount of sprays socrates has.

int Socrates::getSpray() const
{
	return m_spray;
} //returns the amount of sprays socrates has.

void Socrates::incFlame() //Increases Socrate's flames by five, used by flamethrower goodie.
{
	m_flame = m_flame + 5;
}

int Socrates::getFlame() const
{
	return m_flame;
}

DirtPile::DirtPile(StudentWorld* s, double x, double y) : Actor(s, IID_DIRT, x, y, 0, 1)
{

}

bool DirtPile::takeDamage(int damage)
{
	setAlive(false);
	return true;  
} //Socrates are instantly killed once they take damage from flames or spray

Food::Food(StudentWorld* s, double x, double y) : Actor(s, IID_FOOD, x, y, 90, 1)
{

}


Pit::Pit(StudentWorld* s, double x, double y) : Actor(s, IID_PIT, x, y, 0, 1)
{

}

void Pit::doSomething()
{
	int emptystatus = 0, choice = 0;
	for (int i = 0; i < 3; i++)
		if (inventory[i] > 0)
			emptystatus++;
	if (emptystatus != 0)
	{
		if (randInt(0, 49) == 0)
		{
			getWorld()->playSound(SOUND_BACTERIUM_BORN);
			if (emptystatus == 1)
				choice = 0;
			else if (emptystatus == 2)
				choice = randInt(0, 1);
			else choice = randInt(0, 2);
			emptystatus = 4;
			int n;
			for (int i = 0; i < 3; i++)
			{
				n = (i + choice) % 3;
				if (inventory[n] > 0 && emptystatus == 4)
				{
					emptystatus = n;
				}
			}
				inventory[emptystatus]--;
				if (emptystatus == 0)
					getWorld()->addActor(new Regular_Salmonella(getWorld(), getX(), getY()));
				else if (emptystatus == 1)
					getWorld()->addActor(new Aggressive_Salmonella(getWorld(), getX(), getY()));
				else if (emptystatus == 2)
					getWorld()->addActor(new EColi(getWorld(), getX(), getY()));
		}
	}
	else 
	{
		setAlive(false);
	}
} //Pits randomly select one of the remaining nonempty types of bacteria they have remaining then emit one of the bacteria (of a random type with uniform distribution).

Projectile::Projectile(StudentWorld* s, int image, double x, double y, Direction dir, int lifetime, int damage) : Actor(s, image, x, y, dir, 1)
{
	m_lifetime = lifetime;
	m_damage = damage;
} //Lifetime is total allowed travel distance of the projectile, damage is the amount of damage the projectile will do.

void Projectile::decLifetime(int lifet)
{
	m_lifetime = m_lifetime - lifet;
}

int Projectile::getLifetime() const
{
	return m_lifetime;
}

void Projectile::setDamage(int d)
{
	m_damage = d;
}

int Projectile::getDamage() const
{
	return m_damage;
}

Flame::Flame(StudentWorld* s, double x, double y, Direction dir) : Projectile(s, IID_FLAME, x, y, dir, 32, 5)
{

}


void Projectile::doSomething() //A projectile fires in its direction until it hits something or until it's travelled <lifetime> pixels
{
	if (!this->isAlive()) //Check if projectile should persist next tick
		return;
	if (getWorld()->damageActor(this, m_damage)) //check if  the projectile hit something
		this->setAlive(false);
	this->moveAngle(this->getDirection(), SPRITE_WIDTH); //move in its direction for <SPRITE_WIDTH> pixels.
	decLifetime(SPRITE_WIDTH);
	if (getLifetime() < 0) // If projectile has travlled its maximum amount of pixels, kill it on the next tick.
		this->setAlive(false);
} 

Spray::Spray(StudentWorld* s, double x, double y, Direction dir) : Projectile(s, IID_SPRAY, x, y, dir, 112, 2)
{

}

Goodie::Goodie(StudentWorld* s, int image, double x, double y) : Actor(s, image, x, y, 0, 1)
{

}

void Goodie::setDecay()
{
	int n = randInt(0, 300 - (10 * (getWorld()->getLevel() - 1)));
	if (n > 50)
		m_decay = n;
	else m_decay = 50;
} //Decay is amount of ticks until goodie or fungus disappears.

void Goodie::setPoints(int newpoints)
{
	m_points = newpoints;
} //set points given upon pickup

bool Goodie::takeDamage(int damage)
{
	setAlive(false);
	return true;
} //Goodies are instantly destroyed by spray and flames.

void Goodie::doSomething()
{
	if (m_decay <= 0)
		setAlive(false);
	m_decay--;
	if (!isAlive())
		return;
	Socrates* a;
	a = getWorld()->socratesOverlap(this);
	if (a != nullptr)
	{
		getWorld()->increaseScore(m_points);
		setAlive(false);
		pickUp(a);
	}
} //goodies wil check if they need to disappear and if not will decay by one tick and then check if socrates is overlapping them and if so, do pickup effect as defined by appropiate function.
health_Goodie::health_Goodie(StudentWorld* s, double x, double y) : Goodie(s, IID_RESTORE_HEALTH_GOODIE, x, y)
{
	setPoints(250);
	setDecay();
}

void health_Goodie::pickUp(Socrates* s)
{
	s->setHP(100);
	getWorld()->playSound(SOUND_GOT_GOODIE);
} //Health goodies give 250 points, and restore socrates health.

life_Goodie::life_Goodie(StudentWorld* s, double x, double y) : Goodie(s, IID_EXTRA_LIFE_GOODIE, x, y)
{
	setPoints(500);
	setDecay();
} 

void life_Goodie::pickUp(Socrates* s)
{
	s->getWorld()->incLives();
	getWorld()->playSound(SOUND_GOT_GOODIE);
}//Life goodies give 100 points and give socrates a new life.

flame_Goodie::flame_Goodie(StudentWorld* s, double x, double y) : Goodie(s, IID_FLAME_THROWER_GOODIE, x, y)
{
	setPoints(300);
	setDecay();
}

void flame_Goodie::pickUp(Socrates* s)
{
	s->incFlame();
	getWorld()->playSound(SOUND_GOT_GOODIE);
} //Flame goodies increase the amount of flames socrates has by 5.

Fungus::Fungus(StudentWorld* s, double x, double y) : Goodie(s, IID_FUNGUS, x, y)
{
	setPoints(-50);
	setDecay();
}

void Fungus::pickUp(Socrates* s)
{
	s->setHP(s->getHP() - 20);
} //Upon overlapping with socrates, fungi will damage socrates by 20 hp.

Bacterium::Bacterium(StudentWorld* s, int imageID, double x, double y) : Agent(s, imageID, x, y, 90)
{

}

bool Bacterium::takeDamage(int damage)
{
	setHP(getHP() - damage);
	if (getHP() <= 0)
	{
		this->soundWhenDies();
		setAlive(false);
		getWorld()->increaseScore(100);
		if (randInt(0, 1) == 0)
		{
			getWorld()->addActor(new Food(getWorld(), getX(), getY()));
		}
	}
	else soundWhenHurt();
	return true;
} //Bacteria take damage and if they die, will have a 50% chance to drop food at their location of death.

void Bacterium::bacteriumCheck()//Helper function for Bacteria AI, common to all bacteria.
{
	Socrates* a;
	a = getWorld()->socratesOverlap(this);
	if (a != nullptr)
	{
		a->takeDamage(m_damage);
		return;
	} //First check if you overlap with socrates, if so damage him.
	if (foodEaten >= 3)
	{
		double x = getX(), y = getY(), newx, newy;
		if (x < VIEW_WIDTH / 2)
			newx = x + SPRITE_WIDTH / 2;
		else if (x > VIEW_WIDTH / 2)
			newx = x - SPRITE_WIDTH / 2;
		else newx = x;
		if (y < VIEW_WIDTH / 2)
			newy = y + SPRITE_WIDTH / 2;
		else if (y > VIEW_WIDTH / 2)
			newy = y - SPRITE_WIDTH / 2;
		else newy = y;
		reproduce(newx, newy);
		foodEaten = 0;
		return;
	} //If this bacterium has eaten 3 food, then reproduce by producing a new bacterium of the same kind (as defined by the reproduce function) at specified newx, newy location.
	Actor* ac = getWorld()->edibleOverlap(this);
	if (ac != nullptr)
	{
		ac->setAlive(false);
		foodEaten++;
	} //Check to see if bacterium overlaps with food and if so "eat" it by increasing food eaten and deleting that food.
}

void Bacterium::setDamage(int damage)
{
	m_damage = damage;
}

void Bacterium::setSpeed(int speed)
{
	m_speed = speed;
}

void Bacterium::doSomething()
{

}

bool Bacterium::checkForDirtandMaybeMove()
{
	double x = getX() + m_speed * cos(getDirection() * (2. * 3.14159 / 360.)), y = getY() + m_speed * sin((getDirection() * (2. * 3.14159 / 360.)));
	if (!getWorld()->isBacteriumMovementBlockedAt(x, y)) //Can this bacterium move to its proposed new location? Note dirt and the edge of the petrie dish are the only things that can prevent them.
	{
		moveTo(x, y);
		return true;
	} //If so, do so and return true
	else return false; //If not return false.
}

Salmonella::Salmonella(StudentWorld* s, double x, double y) : Bacterium(s, IID_SALMONELLA, x, y)
{

}

void Salmonella::setMovementPlan(int newplan)
{
	m_movement_plan = newplan;
}

void Salmonella::persueFood() //Helper function for AI of salmonella bacteeria.
{
	bool flow = 0;
	if (m_movement_plan > 0)
	{
		if (checkForDirtandMaybeMove())
		{
			m_movement_plan--;
			return; //If this bacteria can move, do so and skip the next step and decrement the movement plan counter.
		}
		flow = 1;//If this bacteria has a movement plan greater than zero, skip the next step.
	} 
	int angle;
	if (flow == 0 && getWorld()->getAngleToNearestNearbyEdible(this, 128, angle))
	{
		if (checkForDirtandMaybeMove())
			return;
	} //If this salmonella did not have a movement plan and there exists an edible with 128 pixels then set angle towards that food and try and move towards it.
	angle = randInt(0, 359);
	setDirection(angle);
	setMovementPlan(10);
		
}

Regular_Salmonella::Regular_Salmonella(StudentWorld* s, double x, double y) : Salmonella(s, x, y)
{
	setDamage(1);
	setSpeed(3);
	setHP(4);
}

void Regular_Salmonella::doSomething()
{
	if (!isAlive())
		return;
	bacteriumCheck();
	persueFood();
}//Check helper function for specific order of checks and actions.

Aggressive_Salmonella::Aggressive_Salmonella(StudentWorld* s, double x, double y) : Salmonella(s, x, y)
{
	setDamage(2);
	setSpeed(3);
	setHP(10);
}

bool Aggressive_Salmonella::persueSocrates() //Helper funciton for aggressive salmonella AI
{
	int angle = 0;
	if (getWorld()->getAngleToNearbySocrates(this, 72, angle))
	{
		setDirection(angle);
		checkForDirtandMaybeMove();
		return true;
	} //Is socrates within 72 pixels of this aggressive salmonella? If so, set the direction towards him and move towards him and return true. Return false otherwise.
	return false;
}

void Aggressive_Salmonella::doSomething()
{
	bool flow = 0;
	if (!isAlive())
		return;
	if (persueSocrates())
		flow = 1;
	bacteriumCheck();
	if (flow == 0)
		persueFood();
}

EColi::EColi(StudentWorld* s, double x, double y) : Bacterium(s, IID_ECOLI, x, y)
{
	setDamage(4);
	setSpeed(2);
	setHP(5);
}

bool EColi::persueSocrates()
{
	int angle = 0;
	if (getWorld()->getAngleToNearbySocrates(this, 256, angle))
	{
		for (int i = 0; i < 10; i++)
		{
			setDirection((angle + i*10) % 360);
			if (checkForDirtandMaybeMove())
				return false;
		}
	}
	return false;
} //If socrates is withing 256 pixels, get that angle and attempt to move towards him, if blocked by a dirt pile then try 10 degrees to the left and try moving again, repeat 10x until moved or don't move at all.

void EColi::doSomething()
{
	bacteriumCheck();
	persueSocrates();
}
//Below functions are used for when bacteria have eaten 3 food and will reproduce a copy at their given location.
void Aggressive_Salmonella::reproduce(double newx, double newy)
{
	getWorld()->addActor(new Aggressive_Salmonella(getWorld(), newx, newy));
}

void Regular_Salmonella::reproduce(double newx, double newy)
{
	getWorld()->addActor(new Regular_Salmonella(getWorld(), newx, newy));
}

void EColi::reproduce(double newx, double newy)
{
	getWorld()->addActor(new EColi(getWorld(), newx, newy));
}