Kontagion is a game I programmed (over 1k lines of code) for project 3 of CS 32 at UCLA.

The sound and graphics engine were provided and I did NOT implement them myself.

Press space to shoot a spray, enter to emit flames, and arrow keys to move, your goal is to kill all bad cells that pop out of the pits on screen.

I implemented studentworld.cpp, studentworld.h, actor.cpp, and actor.h

see report.txt for an explanation of the heriarchy of classes/actors.

If you're on Windows, I included Kontagion.sln for easy compiling (compiled under Visual Studio 2019).